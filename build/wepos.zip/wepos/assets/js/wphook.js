pluginWebpack([4],{

/***/ 395:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _hooks = __webpack_require__(34);

window.wepos.wpPackages = {
    hooks: (0, _hooks.createHooks)()
};

/***/ })

},[395]);